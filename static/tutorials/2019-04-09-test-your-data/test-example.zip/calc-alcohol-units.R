library("readr")
library("dplyr")
library("usethis")
library("testthat")
library("tidyr")

url = "https://philmikejones.me/tutorials/2019-04-09-test-your-data/bcs70.csv"
bcs70 = read_csv(url)

bcs70 =
  bcs70 %>%
  mutate(
    beer_units = beer * 2.3,
    cider_units = cider * 2.6,
    sherry_units = sherry * 1.8,
    wine_units = wine * 1.8,
    shandy_units = shandy * 2.3 / 2,
    spirits_units = spirits * 1.0
  ) %>%
  replace_na(list(
    beer_units = 0.0,
    cider_units = 0.0,
    sherry_units = 0.0,
    wine_units = 0.0,
    shandy_units = 0.0,
    spirits_units = 0.0
  )) %>%
  mutate(
    total_units =
      beer_units + cider_units + sherry_units + wine_units +
      shandy_units + spirits_units
  ) %>%
  mutate(
    total_units = if_else(
      {
        is.na(beer) & is.na(cider) & is.na(sherry) &
        is.na(wine) & is.na(shandy) & is.na(spirits)
      },
      NA_real_,
      total_units
    )
  ) %>%
  mutate(
    total_units = if_else(
      is.na(total_units) & !is.na(days_drink),
      0.0,
      total_units
    )
  )

saveRDS(bcs70, "data/bcs70.rds")
