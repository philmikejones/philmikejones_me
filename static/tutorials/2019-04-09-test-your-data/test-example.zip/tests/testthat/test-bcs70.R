library("testthat")
context("Test bcs70")

bcs70 = readRDS("data/bcs70.rds")

test_that("Calculated units are numeric", {
  expect_type(bcs70$beer_units, "double")
  expect_type(bcs70$cider_units, "double")
  expect_type(bcs70$sherry_units, "double")
  expect_type(bcs70$wine_units, "double")
  expect_type(bcs70$shandy_units, "double")
  expect_type(bcs70$spirits_units, "double")
  expect_type(bcs70$total_units, "double")
})

test_that("Calculated minimum units are 0.0", {
  expect_gte(min(bcs70$beer_units, na.rm = TRUE), 0.0)
  expect_gte(min(bcs70$cider_units, na.rm = TRUE), 0.0)
  expect_gte(min(bcs70$sherry_units, na.rm = TRUE), 0.0)
  expect_gte(min(bcs70$wine_units, na.rm = TRUE), 0.0)
  expect_gte(min(bcs70$shandy_units, na.rm = TRUE), 0.0)
  expect_gte(min(bcs70$spirits_units, na.rm = TRUE), 0.0)
  expect_gte(min(bcs70$total_units, na.rm = TRUE), 0.0)
})

test_that("Calculated maximum units are 180.0/1080.0", {
  expect_lte(max(bcs70$beer_units, na.rm = TRUE), 180.0)
  expect_lte(max(bcs70$cider_units, na.rm = TRUE), 180.0)
  expect_lte(max(bcs70$sherry_units, na.rm = TRUE), 180.0)
  expect_lte(max(bcs70$wine_units, na.rm = TRUE), 180.0)
  expect_lte(max(bcs70$shandy_units, na.rm = TRUE), 180.0)
  expect_lte(max(bcs70$spirits_units, na.rm = TRUE), 180.0)
  expect_lte(max(bcs70$total_units, na.rm = TRUE), 1080.0)
})

test_that("No missing data when there should be data", {
  expect_false(any(is.na(bcs70$total_units[!is.na(bcs70$beer)])))
  expect_false(any(is.na(bcs70$total_units[!is.na(bcs70$cider)])))
  expect_false(any(is.na(bcs70$total_units[!is.na(bcs70$sherry)])))
  expect_false(any(is.na(bcs70$total_units[!is.na(bcs70$wine)])))
  expect_false(any(is.na(bcs70$total_units[!is.na(bcs70$shandy)])))
  expect_false(any(is.na(bcs70$total_units[!is.na(bcs70$spirits)])))
})

test_that("True zero coded", {
  expect_false(any(is.na(bcs70$total_units[!is.na(bcs70$days_drink)])))
})
